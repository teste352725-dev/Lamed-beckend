
export async function createPixCharge(data) {
  console.log('createPixCharge called with:', data);
  // Simulação de resposta da Efí
  return { 
    message: "Pix backend ok (stub)",
    txid: "79635dfcf73c4c99a70014a01c40b8f0",
    pixCopiaECola: "00020101021226840014br.gov.bcb.pix2562payload.psp.com/v2/79635dfcf73c4c99a70014a01c40b8f05204000053039865802BR5913CLIENTE TESTE6008BRASILIA62070503***6304E22A",
    status: "ATIVA"
  };
}

export async function createCardCharge(data) {
  console.log('createCardCharge called with:', data);
  return { id: 1001, status: 'approved', message: "Cartão backend ok (stub)" };
}

export async function handleWebhookNotification(data) {
  console.log('handleWebhookNotification called with:', data);
}
